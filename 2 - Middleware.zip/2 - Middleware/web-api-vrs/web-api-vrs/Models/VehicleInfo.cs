﻿using System;
using System.Collections.Generic;

namespace web_api_vrs.Models
{
    public partial class VehicleInfo
    {
        public VehicleInfo()
        {
            Reservation = new HashSet<Reservation>();
        }

        public int Id { get; set; }
        public string VehicleNumber { get; set; }
        public string VehicleName { get; set; }
        public string Branch { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public DateTime InsuranceExpiryDate { get; set; }
        public DateTime LastServiceDate { get; set; }
        public DateTime ServiceDueDate { get; set; }
        public long Fee { get; set; }

        public virtual ICollection<Reservation> Reservation { get; set; }
    }
}
