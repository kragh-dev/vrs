﻿using System;
using System.Collections.Generic;

namespace web_api_vrs.Models
{
    public partial class Reservation
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public int MemberId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public long Fee { get; set; }
        public bool? DriverNeeded { get; set; }
        public string LicenseNumber { get; set; }
        public long? Refund { get; set; }
        public bool Status { get; set; }
        public string Comments { get; set; }
        public long TransactionId { get; set; }

        public virtual UserInfo Member { get; set; }
        public virtual Payment Transaction { get; set; }
        public virtual VehicleInfo Vehicle { get; set; }
    }
}
