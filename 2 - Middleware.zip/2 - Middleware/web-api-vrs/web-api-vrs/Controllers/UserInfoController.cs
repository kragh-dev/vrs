﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using web_api_vrs.Models;

namespace web_api_vrs.Controllers
{
    [EnableCors("VRSPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfoController : ControllerBase
    {
        vKARContext vKAR = new vKARContext();
        [HttpGet]
        public IActionResult getUsers()
        {
            return Ok(vKAR.UserInfo);
        }
        [Route("approvalStatus/{emailId}/{status}/{comments}")]
        [HttpPut("{emailId}/{status}/{comments}")]
        public IActionResult Approve(string emailId, bool status, string comments)
        {
            UserInfo user = vKAR.UserInfo.Where(usr => usr.EmailId == emailId).FirstOrDefault();
            if (status == true)
            {
                user.Status = status;
                vKAR.SaveChanges();
                return Ok(new { message = "Approved" });
            }
            else
            {
                user.Status = status;
                user.Reject = true;
                user.Comments = comments;
                //vKAR.UserInfo.Update(user);
                vKAR.SaveChanges();
                return Ok(new { message = "Rejected" });
            }
        }
        [Route("getAdminRegistrations")]
        [HttpGet]
        public IActionResult GetAdminRegistrations()
        {
            return Ok(vKAR.UserInfo.Where(user => user.Status == false && user.Role == "admin" && user.Reject == false));
        }
        [Route("getMemberRegistrations")]
        [HttpGet]
        public IActionResult GetMemberRegistrations()
        {
            return Ok(vKAR.UserInfo.Where(user => user.Status == false && user.Role == "user" && user.Reject == false));
        }
        [Route("getReservationOfUser/{id}")]
        [HttpGet("{id}")]
        public IActionResult GetReservationsForUser(int id)
        {
            var reserve = from res in vKAR.Reservation.Where(r => r.MemberId == id)
                          select new
                          {
                              res.VehicleId,
                              res.Id,
                              res.Vehicle.VehicleName,
                              res.Vehicle.VehicleNumber,
                              res.StartDate,
                              res.EndDate,
                              res.Fee,
                              res.Refund,
                              res.Status,
                              res.LicenseNumber,
                              res.DriverNeeded,
                              res.Transaction.FeePaid,
                              res.TransactionId,
                              res.Transaction.PaymentMethod
                          };


            return Ok(reserve);
        }
    }
}




