import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { VehicleService } from 'src/app/service/vehicle.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Vehicle } from 'src/app/models/vehicle';

@Component({
  selector: 'app-vehicle-edit',
  templateUrl: './vehicle-edit.component.html',
  styleUrls: ['./vehicle-edit.component.css']
})
export class VehicleEditComponent implements OnInit {

  vehicleDetails: Vehicle
  vehicleId: number
  editVehicleForm = this.formBuilder.group({
    vehicleNumber: ['',Validators.required],
    vehicleName: ['',Validators.required],
    category: ['',Validators.required],
    branch: ['',Validators.required],
    subCategory: ['',Validators.required],
    insuranceExpiryDate: ['',Validators.required],
    lastServiceDate: ['',Validators.required],
    serviceDueDate: ['',Validators.required],
    fee: ['',Validators.required]
  })
  constructor(private formBuilder: FormBuilder, private vehicleService: VehicleService, private activatedRoute: ActivatedRoute, private datepipe: DatePipe, private router:Router) { }

  ngOnInit() {
    this.vehicleId = this.activatedRoute.snapshot.params['id'] as number
    this.vehicleService.getVehicle(this.vehicleId).subscribe(
      data => {
        this.vehicleDetails = data
        console.log(this.vehicleDetails)
        this.editVehicleForm = this.formBuilder.group({
          vehicleNumber: [this.vehicleDetails.vehicleNumber,Validators.required],
          vehicleName: [this.vehicleDetails.vehicleName,Validators.required],
          category: [this.vehicleDetails.category,Validators.required],
          branch: [this.vehicleDetails.branch,Validators.required],
          subCategory: [this.vehicleDetails.subCategory,Validators.required],
          insuranceExpiryDate: [this.datepipe.transform(this.vehicleDetails.insuranceExpiryDate,'yyyy-MM-dd'),Validators.required],
          lastServiceDate: [this.datepipe.transform(this.vehicleDetails.lastServiceDate,'yyyy-MM-dd'),Validators.required],
          serviceDueDate: [this.datepipe.transform(this.vehicleDetails.serviceDueDate,'yyyy-MM-dd'),Validators.required],
          fee: [this.vehicleDetails.fee,Validators.required]
        })
      }
    )
  }

  onEdit()
  {
    console.log(this.editVehicleForm.value)
    this.vehicleService.editVehicle(this.vehicleId,this.editVehicleForm).subscribe(
      data => {
        if(data['message'] == "Vehicle Details updated Successfully")
        {
          this.router.navigateByUrl('updated')
        }
      }
    )
  }
  onDelete()
  {
    this.vehicleService.deleteVehicle(this.vehicleId).subscribe(
      data => {
        if(data['message'] == "vehicle details deleted")
        {
          this.router.navigateByUrl('removed')
        }
      }
    )
  }

}
