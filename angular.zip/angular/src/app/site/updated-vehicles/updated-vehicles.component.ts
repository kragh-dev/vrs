import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updated-vehicles',
  templateUrl: './updated-vehicles.component.html',
  styleUrls: ['./updated-vehicles.component.css']
})
export class UpdatedVehiclesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
