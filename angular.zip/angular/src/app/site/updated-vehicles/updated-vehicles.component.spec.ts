import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatedVehiclesComponent } from './updated-vehicles.component';

describe('UpdatedVehiclesComponent', () => {
  let component: UpdatedVehiclesComponent;
  let fixture: ComponentFixture<UpdatedVehiclesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatedVehiclesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatedVehiclesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
