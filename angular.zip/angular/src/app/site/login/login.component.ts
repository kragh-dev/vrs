import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  showModal: boolean;
  loginForm: FormGroup;
  isAdmin: boolean = false;
  submitted = false;
  isNotValid: boolean
  message
  rejectMessage
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }
  adminClick()
  {
    this.isAdmin = true;
    console.log(this.isAdmin);
    this.show()
  }
  userClick()
  {
    this.isAdmin = false;
    console.log(this.isAdmin);
    this.show()
  }
  show()
  {
    this.showModal = true; // Show-Hide Modal Check
  }
  //Bootstrap Modal Close event
  hide()
  {
    this.showModal = false;
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
        emailId: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]]
    });
}
// convenience getter for easy access to form fields
get formControls() { return this.loginForm.controls; }
onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    if(this.submitted)
    {
      this.userService.authenticate(this.loginForm).subscribe(
        data => {
          console.log(data)
          //let status = JSON.parse(JSON.stringify(data))['status'];
          if(data['status'] == "Success")
          {
            this.userService.loggedInUser = data['user']
            this.userService.isAdmin = this.userService.loggedInUser.role == "admin" ? true : false
            console.log(this.userService.loggedInUser)
            console.log(this.userService.isAdmin)
            this.router.navigateByUrl("vehicles");
          }
          else if(data['status'] == "Account not approved yet")
          {
            this.isNotValid = true
            this.message = "Account not approved yet"
          }
          else if(data['status'] == "Invalid Credentials")
          {
            this.isNotValid = true
            this.message = "Invalid Credentials"
          }
          else if(data['status'] == "Your account has been rejected")
          {
            this.isNotValid = true
            this.message = "Your account has been rejected"
            this.rejectMessage = data['user']
          }
        },
        error => console.log(error)
      )
    }
   
}

}
