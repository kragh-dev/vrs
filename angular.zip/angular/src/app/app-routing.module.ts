import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { SignupComponent } from './site/signup/signup.component';
import { VehicleListComponent } from './vehicle/vehicle-list/vehicle-list.component';
import { AddVehicleDetailsComponent } from './vehicle/add-vehicle-details/add-vehicle-details.component';
import { RegisteredUsersComponent } from './user/registered-users/registered-users.component';
import { AuthGuard } from './guards/auth.guard';
import { SubmittedForApprovalComponent } from './site/submitted-for-approval/submitted-for-approval.component';
import { ReserveComponent } from './vehicle/reserve/reserve.component';
import { VehicleEditComponent } from './vehicle/vehicle-edit/vehicle-edit.component';
import { RemovedFromVehiclesComponent } from './site/removed-from-vehicles/removed-from-vehicles.component';
import { UpdatedVehiclesComponent } from './site/updated-vehicles/updated-vehicles.component';
import { ViewReservationComponent } from './vehicle/view-reservation/view-reservation.component';
import { CancelComponent } from './vehicle/cancel/cancel.component';


const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'submitted', component:SubmittedForApprovalComponent},
  {path:'vehicles', component:VehicleListComponent},
  {path:'addVehicle', component:AddVehicleDetailsComponent, canActivate:[AuthGuard]},
  {path:'registrationRequests', component:RegisteredUsersComponent, canActivate:[AuthGuard]},
  {path:'reserve/:id', component:ReserveComponent, canActivate:[AuthGuard]},
  {path:'edit/:id', component:VehicleEditComponent, canActivate:[AuthGuard]},
  {path:'removed', component:RemovedFromVehiclesComponent, canActivate:[AuthGuard]},
  {path:'updated',component:UpdatedVehiclesComponent, canActivate:[AuthGuard]},
  {path:'reservations',component:ViewReservationComponent, canActivate:[AuthGuard]},
  {path:'cancel/:transactionId', component:CancelComponent, canActivate:[AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
