import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-registered-users',
  templateUrl: './registered-users.component.html',
  styleUrls: ['./registered-users.component.css']
})
export class RegisteredUsersComponent implements OnInit {

  isAdmin : boolean
  adminRegistrationRequests: Observable<any[]>
  memberRegistrationRequests: Observable<any[]>
  showModal : boolean
  emailId : string
  message
  rejectionForm = this.formBuilder.group({
    comments: ['',Validators.required]
  })
  constructor(private userService:UserService, private router:Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.isAdmin = true;
    this.adminRegistrationRequests = this.userService.getAdminRegistrations()
    this.memberRegistrationRequests = this.userService.getMemberRegistrations()
    console.log(this.adminRegistrationRequests)
    console.log(this.memberRegistrationRequests)
  }
  adminClick()
  {
    this.isAdmin = true;
  }
  customerClick()
  {
    this.isAdmin = false;
  }
  show(userEmail:string)
  {
    this.emailId = userEmail
    this.showModal = true
  }
  hide()
  {
    this.showModal = false;
  }
  approve(emailId:string){
    this.userService.approveStatus(emailId,true,'Good to go').subscribe(
      data => {
        this.message = JSON.parse(JSON.stringify(data))['message']
        console.log(this.message)
        if(this.message == "Approved")
        {
          this.adminRegistrationRequests = this.userService.getAdminRegistrations()
          this.memberRegistrationRequests = this.userService.getMemberRegistrations()
        }
      }
    )
  }
  reject(emailId:string){
    this.hide()
    this.userService.approveStatus(emailId,false,this.rejectionForm.get('comments').value).subscribe(
      data => {
        this.message = JSON.parse(JSON.stringify(data))['message']
        console.log(this.message)
        if(this.message == "Rejected")
        {
          this.adminRegistrationRequests = this.userService.getAdminRegistrations()
          this.memberRegistrationRequests = this.userService.getMemberRegistrations()
        }
      }
    )
  }
}
