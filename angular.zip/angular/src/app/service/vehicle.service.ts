import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Vehicle } from 'src/app/models/vehicle';
import { UserService } from './user.service';
import { Reservation } from '../models/reservation';
import { Bookings } from '../models/bookings';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  baseUrl = "http://localhost:5000/api"

  constructor(private http:HttpClient, private userService: UserService) { }
  getVehicles():Observable<any[]>
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<any[]>(this.baseUrl+"/vehicle/getVehicles",options)
  }
  getVehicle(id:number)
  {
    let body = id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<Vehicle>(this.baseUrl+"/vehicle/getVehicleById/"+body,options)
  }
  getCars()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<Vehicle[]>(this.baseUrl+"/vehicle/getCars",options)
  }
  getBikes()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<Vehicle[]>(this.baseUrl+"/vehicle/getBikes",options)
  }
  addVehicle(vehicleDetails:any)
  {
    let body = JSON.stringify(vehicleDetails.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.post(this.baseUrl+"/vehicle/addVehicle",body,options)
  }
  editVehicle(id:any,vehicleDetails:any)
  {
    let body = JSON.stringify(vehicleDetails.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.put(this.baseUrl+"/vehicle/editVehicle/"+id,body,options)
  }
  deleteVehicle(id:number)
  {
    let body = id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.delete(this.baseUrl+"/vehicle/deleteVehicle/"+body,options)
  }
  reserveVehicle(reservationDetails:any)
  {
    let body = JSON.stringify(reservationDetails.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.post(this.baseUrl+"/reservation/reserveVehicle/",body,options)
  }
  checkDates(id:any,startDate:any,endDate:any)
  {
    let body = id+"/"+startDate+"/"+endDate
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<any>(this.baseUrl+"/reservation/checkDates/"+body,options)
  }
  getReservations()
  {
    let data = this.userService.loggedInUser.id
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<Bookings[]>(this.baseUrl+"/userInfo/getReservationOfUser/"+data,options)
  }
  cancelReservation(transactionId:any,comment:any)
  {
    let data = transactionId+"/"+comment
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.put(this.baseUrl+"/reservation/cancelBooking/"+data,options)
  }
  getReservationDetails(transactionId:any)
  {
    let data = transactionId
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.put(this.baseUrl+"/reservation/getReservation/"+data,options)
  }
}
