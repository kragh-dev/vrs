import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = "http://localhost:5000/api"
  loggedInUser: User
  isAdmin:boolean
  adminRegistrationRequests: User
  memberRegistrationRequests: User

  constructor(private http:HttpClient) { }
  //login
  authenticate(credentials:any)
  {
    let body = JSON.stringify(credentials.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.post(this.baseUrl+"/auth",body,options)
  }
  //checkEmialRegistration
  checkEmail(emailId:string)
  {
    let body = emailId
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType':'text' })
    let options = { headers: header }
    return this.http.get(this.baseUrl+"/registration/checkEmail/"+body,options)
  }
  //registration
  register(userDetails:any)
  {
    let body = JSON.stringify(userDetails.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.post(this.baseUrl+"/registration",body,options)
  }
  //new admin registrations
  getAdminRegistrations():Observable<any[]>
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<any[]>(this.baseUrl+"/userInfo/getAdminRegistrations",options)
  }
  //new member registrations
  getMemberRegistrations():Observable<any[]>
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get<any[]>(this.baseUrl+"/userInfo/getMemberRegistrations",options)
  }
  //approve/reject member
  approveStatus(email:any, status:any, comments:any)
  {
    let data = email+"/"+status+"/"+comments
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.put(this.baseUrl+"/userInfo/approvalStatus/"+data,options)
  }
  onLogout()
  {
    this.loggedInUser = null
    this.isAdmin = false
  }
}
