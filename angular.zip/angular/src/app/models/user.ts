export class User {
    id:number;
    empId:number;
    firstName:string;
    lastName:string;
    age:number;
    gender:string;
    contactNumber:number;
    emailId:string;
    passsword:string;
    branch:string;
    role:string;
}
