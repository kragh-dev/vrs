export class Payment {
    transactionId?: number
    memberId?: number
    paymentMethod?: string
    feePaid?: number
    transactionStatus?: string
}
